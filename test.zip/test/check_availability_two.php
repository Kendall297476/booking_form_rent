<?php
// Database configuration
$servername = "localhost";
$username = "uvwjwzmy_wp1077";
$password = "h62@34.p3S";
$dbname = "uvwjwzmy_wp1077";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Retrieve date
$date = $_POST['date'];
// Check number of bookings for the selected date
$sql = "SELECT COUNT(*) as count FROM deliveries WHERE date = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $date);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$bookingCount = $row['count'];
// Limit to 2 bookings per date
if ($bookingCount >= 3) {
    echo "Date is fully booked. Please select a different date.";
} else {
    echo "Date is available";
}
// Close connection
$stmt->close();
$conn->close();
?>