<!DOCTYPE html>
<html lang="en">

<head>

    <title>A. P. Haulers</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js">
    </script>
    <!-- Stripe.js -->
    <script src="https://js.stripe.com/v3/"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDePMyVrSXbivr7faWH_7KYhXklWX4pXes"></script>
    <link rel="icon" type="image/x-icon" href="../wp-content/uploads/2024/08/resize.png">
    
    <!-- DM Sans Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap" rel="stylesheet">
    
    <!-- Inter Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap" rel="stylesheet">
    
    <style>
        .error-message {
            color: red;
            font-weight: bold;
        }

        body {
            background: #F0EFED;
        }
        h1,h2,h3,h4,h5,h6{
            font-family: "DM Sans", sans-serif !important;
        }
        p,label,a,div,input{
            font-family: "Inter", sans-serif;
            font-size:16px;
        }
        
        .box {
            background: white;
            padding: 40px;
            margin-top: 100px;
            border-radius: 25px;
        }
        button#checkout-button {
            background: #E17334;
            padding: 8px 28px;
            color: white;
            border: 1px solid #E17334;
            border-radius: 20px;
            font-size: 18px;
        }
        button#checkout-button:hover {
            background: #019ECB;
            padding: 8px 28px;
            color: white;
            border: 1px solid #019ECB;
            border-radius: 20px;
            font-size: 18px;
        }
        input {
            padding: 8px 25px;
            width:250px;
        }
        select#time {
        padding: 8px 15px;
        width: 250px;
        }
        
        div{
            font-size:18px;
        }
        
        .form-group {
            
        display: flex;
        justify-content: space-between;
        
        }
        
        
    </style>
    
    
</head>

<body>



    <div class="form-container container">

        <div class='row'>
            <div class='col-md-3'>
            </div>

            <div class='col-md-6'>
                <div class='box'>
                <center>
                    <br><br>

                    <a href='#'>
                        <img src='https://autobyte-solution.com/peter/wp-content/uploads/2024/08/resize.png'
                            style='width:100px'> </a>
                    <h1> Book</h1>
                    <h2> Local & Intercity moves ( Three Bedroom Apartment ) </h2>
                    <br>
                      <form id="delivery-form" method="post" action="submit_form.php">
                            <div class="form-group">
                                <label for="fullname">Full Name:</label>
                                <input type="text" id="fullname" placeholder='Enter your Name' name="fullname" required>
                            </div>
                            <div class="form-group">
                                <label for="emails">Email:</label>
                                <input type="email" id="emails" placeholder='Enter your Email' name="email" required>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone:</label>
                                <input type="tel" id="phone" placeholder='Enter your Phone' name="phone" required>
                            </div>
                            <!-- Moved Item Number Field here, after phone -->
                            <div class="form-group">
                                <label for="item">Item:</label>
                                <input type="text" id="item" placeholder='Enter the Item' name="item" required>
                            </div>
                         
                         
                            <div class="form-group">
                                <label for="item">Item Number:</label>
                                <input type="text" id="item_number" placeholder='Enter the Item Number' name="item_number" required>
                            </div>
                            <div class="form-group">
                                <label for="pickup">Pickup Location:</label>
                                <input type="text" id="pickup" placeholder='Enter your location' name="pickup_location" required>
                            </div>
                            <div class="form-group">
                                <label for="delivery">Delivery Location:</label>
                                <input type="text" id="delivery" placeholder='Enter your location' name="delivery_location" required>
                            </div>
                            <div class="form-group">
                                <label for="date">Date Slot:</label>
                                <input type="date" id="date" name="date" required>
                            </div>
                            <!-- New Specific Time Field -->
                           <div class="form-group">
                            <label for="time"> Time:</label>
                            <select id="time" name="specific_time" required>
                                <option value="" disabled selected>Select a time slot</option>
                                <option value="08:00">7am-12pm </option>
                                <option value="09:00">12:30 pm - 6PM</option>
                    
                            </select>
                        </div>
                            <input type="hidden" id="distance" name="distance">
                            <input type="hidden" id="cost" name="cost">
                            <div id="distance-display">Distance: -- miles</div>
                            <div id="cost-display">Cost: $899 </div>
                            <div id="error-message" class="error-message"></div>
                            <br>
                            <button id="checkout-button" type="button">Process to Checkout</button>
                        </form>
                </center>
                </div>
            </div>


            <div class='col-md-3'>
            </div>

        </div>
    </div>

    <script>
         const centerLocation = new google.maps.LatLng(40.092, -74.949); // Latitude and Longitude for 222 Bristol Pike, Bristol, PA 19007, USA
    const radiusInMiles = 50;
    const validPickupAreas = [
        "Camden", 
        "Wilmington", 
        "Reading", 
        "Trenton", 
        "Vineland", 
        "Conshohocken", 
        "Dover", 
        "Chester", 
        "Upper Darby", 
        "Media", 
        "Middletown Township", 
        "Hammonton", 
        "Pennsauken Township", 
        "Norristown", 
        "Doylestown", 
        "Cherry Hill", 
        "West Chester", 
        "Evesham", 
        "Washington Township", 
        "Millville", 
        "Salem", 
        "Cape May Court House", 
        "Lower Township", 
        "The Wildwoods", 
        "Brigantine", 
        "Ventnor City", 
        "Margate City", 
        "Sea Isle City", 
        "Haverford", 
        "Bridgeton", 
        "Coatesville", 
        "Lower Merion", 
        "Gloucester Township", 
        "Downingtown", 
        "Phoenixville", 
        "New Castle", 
        "Pottstown", 
        "King of Prussia", 
        "Bensalem Township", 
        "Burlington City", 
        "Burlington Township", 
        "Middle Township (Cape May County)", 
        "Mount Holly", 
        "Newark", 
        "Hamilton Township (Mays Landing)", 
        "Woodbury",
        "Elkton", 
        "Cheltenham Township", 
        "Abington Township", 
        "Bristol Township", 
        "Mount Laurel", 
        "Northampton Township", 
        "Winslow Township", 
        "New Hope", 
        "Falls Township", 
        "Middletown Township (Bucks County)", 
        "Egg Harbor Township", 
        "Galloway Township", 
        "Pennsville", 
        "Maurice River Township"
    ];

    document.getElementById('pickup').addEventListener('input', autoCalculate);
    document.getElementById('delivery').addEventListener('input', autoCalculate);

    function autoCalculate() {
        const pickupLocation = document.getElementById("pickup").value;
        const deliveryLocation = document.getElementById("delivery").value;

        if (pickupLocation && !isValidPickupArea(pickupLocation)) {
            document.getElementById('error-message').innerText = 'Pickup location is out of service area. Please enter a valid location.';
            return;
        } else {
            document.getElementById('error-message').innerText = '';
        }

        if (pickupLocation && deliveryLocation) {
            const service = new google.maps.DistanceMatrixService();
            service.getDistanceMatrix(
                {
                    origins: [pickupLocation],
                    destinations: [deliveryLocation],
                    travelMode: 'DRIVING',
                    unitSystem: google.maps.UnitSystem.METRIC,
                }, callback);
        }
    }

        function isValidPickupArea(location) {
            return validPickupAreas.some(area => location.toLowerCase().includes(area.toLowerCase()));
        }

    function callback(response, status) {
        if (status == 'OK') {
            const origin = response.originAddresses[0];
            const destination = response.destinationAddresses[0];
            if (response.rows[0].elements[0].status === "OK") {
                const distanceInMeters = response.rows[0].elements[0].distance.value;
                const distanceInKm = (distanceInMeters / 1000).toFixed(2);

                // Conversion to miles
                const distanceInMiles = (distanceInKm * 0.621371).toFixed(2);
                const baseRate = 899;
                const cost = calculateCost(distanceInMiles, baseRate);
                document.getElementById("distance-display").innerText = "Distance: " + distanceInMiles + " miles";
                document.getElementById("cost-display").innerText = "Cost: $" + cost;
                document.getElementById("distance").value = distanceInMiles;
                document.getElementById("cost").value = cost;
            } else {
                document.getElementById('error-message').innerText = 'Unable to find the distance between locations. Please check the addresses.';
            }
        } else {
            document.getElementById('error-message').innerText = 'Error with distance calculation service.';
        }
    }

    function calculateCost(distance, baseRate) {
        const ratePerMile = 0.50;
        return (baseRate + (distance * ratePerMile)).toFixed(2);
    }
    
    

        // Stripe Integration
        const stripe = Stripe('pk_test_51LbpIsRT3MjYCnBGCbyLD5a8ydnp0zfIbde7UvtRInUP39uSLOaQOv0ZYJ8dyJ8enlGIS3O4miziPvGCMbuY3um900xsG7yKpj');  // Replace with your Stripe publishable key

        document.getElementById('checkout-button').addEventListener('click', async () => {
            const date = document.getElementById('date').value;
            const cost = document.getElementById('cost').value;

            if (!date) {
                document.getElementById('error-message').innerText = 'Please select a date.';
                return;
            }

            // Check availability of the selected date
            const response = await fetch('check_availability_three.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({ date: date })
            });

            const result = await response.text();
            if (result === 'Date is fully booked. Please select a different date.') {
                document.getElementById('error-message').innerText = result;
                return;
            }

            if (!cost) {
                document.getElementById('error-message').innerText = 'Please calculate cost first by entering both locations.';
                return;
            }

            // If date is available, proceed to Stripe payment
            try {
                const sessionResponse = await fetch('create-checkout-session.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        amount: Math.round(cost * 1)  // Convert PKR to paisa (smallest unit)
                    }),
                });

                const session = await sessionResponse.json();
                // Redirect to Stripe Checkout
                const result = await stripe.redirectToCheckout({ sessionId: session.id });

                if (result.error) {
                    document.getElementById('error-message').innerText = result.error.message;
                }
            } catch (error) {
                console.error('Error:', error);
                document.getElementById('error-message').innerText = 'Payment process failed. Please try again.';
            }
        });                                             
    </script>

</body>

</html>